package com.booking.flight.repository;

import java.util.ArrayList;
import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;

import com.booking.flight.model.Bookings;
import com.booking.flight.model.Flight;

public interface FlightSearchRepository extends JpaRepository<Flight, Integer> {
	
	//ArrayList<Flight> findByFromDestinationAndToDestination(String from, String to);
	ArrayList<Flight> findByFromDestinationAndToDestinationAndDateOfTravelAndRound(String from, String to,String travledate, String onewayrond);
	//ArrayList<Flight> findByDateOfTravelAndRoundOrOneWay(Date traveldate, String roundoneway);

}
