package com.booking.flight.model;

import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonProperty;


//@Data

@Entity
@Table(name ="Flight")
public class Flight {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "Id")
	@JsonProperty("id")
    public int id;
	
	@Column(name = "Flight_Id")
	@JsonProperty("flight_Id")
    public String flightId;
	
	@Column(name = "Flight_Name")
	@JsonProperty("flightName")
    public String flightName;
	
	/*@Column(name = "Airline_Id")
	@JsonProperty("airline_Id")
    public int airlineId;
	
	@Column(name = "Airline_Name")
	@JsonProperty("airlineName")
    public String airlineName;*/
	
	@Column(name = "From_Destination")
	@JsonProperty("fromDestination")
    public String fromDestination;
	
	
	@Column(name = "To_Destination")
	@JsonProperty("toDestination")
    public String toDestination;
	
	@Column(name = "Date_Of_Travel")
	@JsonProperty("dateOfTravel")
    public String dateOfTravel;
	
	
	@Column(name = "Flight_Start_Time")
	@JsonProperty("flightStartTime")
    public Time flightStartTime;
	
	
	@Column(name = "Flight_Arrival_Time")
	@JsonProperty("flightArrivalTime")
    public Time flightArrivalTime;
	
	@Column(name = "From_Airport")
    @JsonProperty("fromAirport")
    private String fromAirport;
	
	@Column(name = "To_Airport")
	@JsonProperty("toAirport")
    private String toAirport;
	
	@Column(name = "Price")
	@JsonProperty("price")
    private String price;
	
	@Column(name = "round_or_one_way")
	@JsonProperty("roundOrOneWay")
    private String round;
	
	@Column(name = "Seats_Left")
	@JsonProperty("noOfSeatsLeft")
    private String noOfSeatsLeft;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	public String getNoOfSeatsLeft() {
		return noOfSeatsLeft;
	}

	public void setNoOfSeatsLeft(String noOfSeatsLeft) {
		this.noOfSeatsLeft = noOfSeatsLeft;
	}

	public String getFlightId() {
		return flightId;
	}

	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	/*public String getAirlineName() {
		return airlineName;
	}

	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}*/

	public String getFromDestination() {
		return fromDestination;
	}

	public void setFromDestination(String fromDestination) {
		this.fromDestination = fromDestination;
	}

	public String getToDestination() {
		return toDestination;
	}

	public void setToDestination(String toDestination) {
		this.toDestination = toDestination;
	}

	

	public Time getFlightStartTime() {
		return flightStartTime;
	}

	public void setFlightStartTime(Time flightStartTime) {
		this.flightStartTime = flightStartTime;
	}

	public Time getFlightArrivalTime() {
		return flightArrivalTime;
	}

	public void setFlightArrivalTime(Time flightArrivalTime) {
		this.flightArrivalTime = flightArrivalTime;
	}

	public String getFromAirport() {
		return fromAirport;
	}

	public void setFromAirport(String fromAirport) {
		this.fromAirport = fromAirport;
	}

	public String getToAirport() {
		return toAirport;
	}

	public void setToAirport(String toAirport) {
		this.toAirport = toAirport;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	

	
	
	
	
}

