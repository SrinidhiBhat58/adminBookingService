package com.booking.flight.controller;

import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.booking.flight.model.Bookings;
import com.booking.flight.model.Flight;
import com.booking.flight.service.BookingService;

@RequestMapping("/user")
@RestController
public class FlightBookingController {
	
	@Autowired
	private BookingService bookingService;
	
	
	@RequestMapping(value = "/api/v1.0/flight/booking/{flight_id}", method = RequestMethod.POST)
	public String bookingRequest(@RequestBody Bookings bookings,
			//@PathVariable final String flight_id,
			HttpServletResponse httpResponse) {
		
		String msg=bookingService.bookingRequestService(bookings);
		httpResponse.setStatus(Integer.parseInt(bookings.getCode()));
		return msg;
	}
	
	@PutMapping(value = "/api/v1.0/flight/booking/cancel/{pnr}")
	public String deleteBooking(@PathVariable final long pnr,
			HttpServletResponse httpResponse) {
		String msg=bookingService.deleteRequestService(pnr);
		return msg;
			
	}
	
	@GetMapping(value = "/api/v1.0/flight/booking/history/{emailId}")
	public ArrayList<Bookings> viewBookingHistory(@PathVariable final String emailId,
			HttpServletResponse httpResponse) {
		ArrayList<Bookings> bookings = new ArrayList<>();
		bookings=bookingService.viewBookingHistoryService(emailId);
		return bookings;
			}
	
	@GetMapping(value = "/api/v1.0/flight/ticket/{pnr}")
	public Bookings viewBookedTicket(@PathVariable final long pnr,
			HttpServletResponse httpResponse) {
	Bookings bookings = new Bookings();
		bookings=bookingService.viewBookedTicketService(pnr);
		return bookings;
			}
	
	@GetMapping(value = "/api/v1.0/flight/search/")
	public ArrayList<Flight> flightSearch(@RequestParam(required = false) final String flighdate, 
											@RequestParam final String from,
											@RequestParam final String to,
											@RequestParam(required = false)  final String roundOrOneWay,
											HttpServletResponse httpResponse) {
		ArrayList<Flight> flight = new ArrayList<>();
		flight=bookingService.flightSearchService(flighdate,from,to,roundOrOneWay);
		return flight;
			}
	
	
	
	
	
	
	
	
	
	
	
	

}
