package com.booking.flight.repository;

import org.springframework.data.repository.CrudRepository;

import com.booking.flight.model.Bookings;
//repository that extends CrudRepository



public interface BookingRepository extends CrudRepository<Bookings, Integer> {

	
}