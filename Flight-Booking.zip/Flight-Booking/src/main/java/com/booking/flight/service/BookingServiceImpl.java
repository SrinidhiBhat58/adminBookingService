package com.booking.flight.service;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.flight.model.Bookings;
import com.booking.flight.model.Flight;
import com.booking.flight.model.PassengerList;
import com.booking.flight.repository.BookingRepository;
import com.booking.flight.repository.FlightSearchRepository;
import com.booking.flight.repository.PassengerRepository;
import com.booking.flight.repository.UpdateRepository;


@Service
public class BookingServiceImpl implements BookingService{
	
	@Autowired
	BookingRepository bookingRepository;
	
	
@Autowired
	PassengerRepository passengerRepository;
	
	@Autowired
	UpdateRepository updateRepository;
	
	@Autowired
	FlightSearchRepository flightSearchRepository;
	
	private static final Logger log = LoggerFactory.getLogger(BookingServiceImpl.class);
		
	@Override
	public String bookingRequestService(Bookings bookings) {
			
			log.info("*** Json Request Received ***" + bookings);
			long pnrnumber = generatePNRNumber();
			ArrayList<PassengerList> passengerList = new ArrayList<>();
			passengerList= bookings.getPassengers();
			passengerList.stream().forEach(passenger -> {
				passenger.setBookingId(bookings.getBookingid());
				passenger.setFlightid(bookings.getFlightid());
				passenger.setPnrNumber(pnrnumber);
				passenger.setStatus("CONFIRMED");
				passengerRepository.save(passenger);
			});
			
			
			String successmsg="BOOKING SUCCESSFUL. YOUR PNR NUMBER IS: " + pnrnumber;
			bookings.setCode("200");
			bookings.setMessage(successmsg);
			bookings.setPnrNumber(pnrnumber);
			bookings.setStatus("CONFIRMED");
			//bookings.setFlightid(bookings.getFlightid());
			bookingRepository.save(bookings);
			return successmsg;
		}



		private long generatePNRNumber() {
			Date date = Calendar.getInstance().getTime();  
           DateFormat dateFormat = new SimpleDateFormat("yyyymmddhhmmss");  
			long pnr=Long.parseLong(dateFormat.format(date));
             System.out.println("Converted String: " + pnr);
             return pnr;
		}



		@Override
		public String deleteRequestService(long pnr) {
			Bookings bookings=updateRepository.findByPnrNumber(pnr);
			bookings.setStatus("CANCELLED");
			bookings.setMessage("Booking Cancelled for PNR No-" + pnr);
			bookingRepository.save(bookings);
			return ("BOOKING CANCELLATION SUCCESSFUL");		}
		
		@Override
		public ArrayList<Bookings> viewBookingHistoryService(String email ) {
			ArrayList<Bookings> bookings = new ArrayList<>();
			bookings=updateRepository.findByEmailid(email);
			bookings.stream().forEach(booking -> {
			long pnr=booking.getPnrNumber();
			passengerRepository.findByPnrNumber(pnr);
			booking.setPassengers(passengerRepository.findByPnrNumber(pnr)); });
			return bookings;		}



		@Override
		public Bookings viewBookedTicketService(long pnr) {
			Bookings bookings=updateRepository.findByPnrNumber(pnr);
			passengerRepository.findByPnrNumber(pnr);
			bookings.setPassengers(passengerRepository.findByPnrNumber(pnr));
			return bookings;
		    }

		@Override
		public ArrayList<Flight> flightSearchService(String flighdate,String from,String to,String roundOneWay) {
			ArrayList<Flight> flights =new ArrayList<>();
			ArrayList<Flight> flightFinal =new ArrayList<>();
			flights=flightSearchRepository.findByFromDestinationAndToDestinationAndDateOfTravelAndRound(from,to,flighdate,roundOneWay);
				
			
			return flights;
			}
	
	
}

		
		
	
/*@Override
public String bookingRequestService(BookingPortalRequest bookingPortalRequest) {
	
	log.info("*** Json Request Received ***" + bookingPortalRequest);
	UUID booking_id = UUID.randomUUID();
	bookingPortalRequest.set
	
	
	
	bookingDAO.bookingRequest(bookingPortalRequest, booking_id.toString());
	log.info("*** Enrollment details stored into DB ***");
	
	return null;
}*/

		/*@Autowired
		EnrollmentDAO enrollmentDAO;

		@Autowired
		BenefitPlanDAO benefitPlanDAO;
		
		@Autowired
		EnrollmentHEService enrollmentHEService;

		@Override
		public EnrollmentResponse enrollment(EnrollmentRequest enrollmentRequest) throws ServiceException {
			EnrollmentResponse enrollmentResponse = new EnrollmentResponse();
			EnrollmentResponseBuilder enrollmentResponseBuilder = new EnrollmentResponseBuilder();
			String errorMsg = "";
			String failureMsg = "";
			String benefitPlanID = "";

			log.info("*** Enrollment Json Request Received ***" + enrollmentRequest.getApplication());
			Gson gson = new Gson();
			UUID uniqueKey = UUID.randomUUID();

			enrollmentDAO.enrollmentRequest(enrollmentRequest, uniqueKey.toString());
			log.info("*** Enrollment details stored into DB ***");
			log.info("*** Find the benefit plan name ***");

			benefitPlanID = benefitPlanDAO.findBenefitPlanNameAndRatingArea(enrollmentRequest);

			log.info("*** Consume HE service ***");
			EnrollmentType enrollmentType = enrollmentHEService.updateEnrollment(enrollmentRequest, benefitPlanID);

			EnrollmentResponseType enrollmentResponseType = enrollmentHEService.getEnrollmentResponse(enrollmentType);
			log.info("*** Received HE Response ***");
			enrollmentResponse = enrollmentResponseBuilder.setResponse(enrollmentRequest, enrollmentResponseType);

			enrollmentDAO.enrollmentResponse(enrollmentType, enrollmentResponseType, enrollmentResponse,
					uniqueKey.toString());

			log.info("*** Update Enrollment Response to DB ***");
			log.info("*** Json Response Returned ***");
			String resJson = gson.toJson(enrollmentResponse);
			log.info("ApplicationId::   " + enrollmentRequest.getApplication().getApplicationId() + "   Json Response::   "
					+ resJson);

			return enrollmentResponse;
		}

	}

}*/
