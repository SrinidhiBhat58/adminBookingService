package com.booking.flight.service;

import java.util.ArrayList;
import java.util.Date;

import com.booking.flight.model.Bookings;
import com.booking.flight.model.Flight;

public interface BookingService {
	
	public String bookingRequestService(Bookings bookings);
	public String deleteRequestService(long pnr);
	public ArrayList<Bookings> viewBookingHistoryService(String email );
	public Bookings viewBookedTicketService(long pnr);
	public ArrayList<Flight> flightSearchService(String flighdate,String from,String to,String roundOrOneWay);

	//public ArrayList<BookingHistoryResponse> getBookingHistory(int emailid);

}//
