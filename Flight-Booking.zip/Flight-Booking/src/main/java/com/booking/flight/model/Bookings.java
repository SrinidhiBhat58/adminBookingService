package com.booking.flight.model;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonProperty;


//@Data

@Entity
@Table(name ="Bookings")
public class Bookings {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "Booking_ID")
	@JsonProperty("booking_id")
    public Integer bookingid;
	
	@Column(name = "User_Name")
	@JsonProperty("user_name")
    public String user_name;
   
	@Column(name = "Email_ID")
	@JsonProperty("email_id")
    public String emailid;
	
	@Column(name = "Status")
	@JsonProperty("status")
    private String status;
    
	@Column(name = "Message")
    @JsonProperty("message")
    private String message;

    
	@Column(name = "Status_Code")
    @JsonProperty("code")
    private String code;
	
	

	@Column(name = "Flight_ID")
	@JsonProperty("flight_id")
    public String flightid;
	
	@Column(name = "PNR_Number")
    @JsonProperty("pnr_number")
    private long pnrNumber;
	
	@Transient
	@JsonProperty("passengers")
	public ArrayList<PassengerList> passengers;
	
	
	public ArrayList<PassengerList> getPassengers() {
		return passengers;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	
	public long getPnrNumber() {
		return pnrNumber;
	}

	public void setPnrNumber(long pnrNumber) {
		this.pnrNumber = pnrNumber;
	}

	public void setPassengers(ArrayList<PassengerList> passengers) {
		this.passengers = passengers;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	
	
	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getFlightid() {
		return flightid;
	}

	public void setFlightid(String flightid) {
		this.flightid = flightid;
	}

	public Integer getBookingid() {
		return bookingid;
	}

	public void setBookingid(Integer bookingid) {
		this.bookingid = bookingid;
	}

	
	/*@JsonProperty("application")
    private Application application;
	
	@JsonProperty("agents")
    private List<Agents> agents;
	
	
	
	
	@JsonProperty("policies")
	private List<Policies> policies;*/

}

