package com.booking.flight.repository;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;

import com.booking.flight.model.Bookings;
import com.booking.flight.model.PassengerList;

public interface PassengerRepository extends JpaRepository<PassengerList, Integer> {
	ArrayList<PassengerList> findByPnrNumber(long pnr);

}
