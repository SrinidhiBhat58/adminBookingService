package com.booking.flight.model;

import java.util.List;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonProperty;


//@Data

@Entity
@Table(name = "Passengers")
public class PassengerList {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "Passenger_Id")
	@JsonProperty("id")
    public int id;
	
	@Column(name = "Passenger_Name")
	@JsonProperty("name")
    public String name;
	
	@Column(name = "Age")
	@JsonProperty("age")
    public String age;
	
	@Column(name = "Gender")
	@JsonProperty("gender")
    public String gender;
	
	
	@Column(name = "Meal_Selected")
	@JsonProperty("meal")
    public Boolean meal;
	
	@Column(name = "Seat_Number")
	@JsonProperty("seat_number")
    public String seatNumber;
	
	
	@Column(name = "Flight_ID")
	@JsonProperty("flight_id")
    public String flightid;
	
	
	@Column(name = "Booking_ID")
	@JsonProperty("booking_id")
    public Integer bookingId;
	
	@Column(name = "PNR_Number")
    @JsonProperty("pnr_number")
    private long pnrNumber;
	
	@Column(name = "Status")
	@JsonProperty("status")
    private String status;


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	

	public long getPnrNumber() {
		return pnrNumber;
	}


	public void setPnrNumber(long pnrNumber) {
		this.pnrNumber = pnrNumber;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getSeatNumber() {
		return seatNumber;
	}


	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}


	public Integer getBookingId() {
		return bookingId;
	}


	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAge() {
		return age;
	}


	public void setAge(String age) {
		this.age = age;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public Boolean getMeal() {
		return meal;
	}


	public void setMeal(Boolean meal) {
		this.meal = meal;
	}


	


	public String getFlightid() {
		return flightid;
	}


	public void setFlightid(String flightid) {
		this.flightid = flightid;
	}
	
	

}
