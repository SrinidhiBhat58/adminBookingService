package com.booking.flight.repository;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.booking.flight.model.Bookings;


@Repository
public interface UpdateRepository extends JpaRepository<Bookings, Integer> {
	/*@Modifying
	@Transactional
    @Query("UPDATE  status from BookingResponse SET status = statuss WHERE pnrNumber= pnr")
    int updateToCancelled(@Param("pnr") long pnr,@Param("statuss") String statuss);*/
	
	Bookings findByPnrNumber(long pnr);
	ArrayList<Bookings> findByEmailid(String email);
	//BookingPortalRequest findByPnrNumberr( long pnr);
}

//update booking_responses set booking_id=statuss where pnr_number=pnr
