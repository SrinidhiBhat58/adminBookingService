package com.admin.flight.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.admin.flight.model.Airlines;

public interface AirlineRepository extends JpaRepository<Airlines, Integer> { 
	
	Airlines findByAirlineId(int aid);

}
