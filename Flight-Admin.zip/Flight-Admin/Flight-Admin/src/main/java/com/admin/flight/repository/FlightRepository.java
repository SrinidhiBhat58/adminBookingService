package com.admin.flight.repository;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;


import com.admin.flight.model.Flight;

public interface FlightRepository extends JpaRepository<Flight, Integer> { 
	
	ArrayList<Flight> findByAirlineId(int aid);

}
