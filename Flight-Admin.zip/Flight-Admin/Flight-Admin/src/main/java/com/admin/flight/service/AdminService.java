package com.admin.flight.service;

import com.admin.flight.model.Airlines;
import com.admin.flight.model.Flight;

public interface AdminService {
	public String addAirlineService(Airlines airline);
	public String blockAirlineService(int airlineId);
	public String addInventoryFlightSchedule(Flight flight);

}
