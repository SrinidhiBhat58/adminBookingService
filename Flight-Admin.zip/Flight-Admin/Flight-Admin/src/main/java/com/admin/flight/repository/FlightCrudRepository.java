package com.admin.flight.repository;

import org.springframework.data.repository.CrudRepository;

import com.admin.flight.model.Flight;



public interface FlightCrudRepository extends CrudRepository<Flight, Integer> {

}
