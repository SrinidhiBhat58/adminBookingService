package com.admin.flight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightAdminApplication.class, args);
	}

}
