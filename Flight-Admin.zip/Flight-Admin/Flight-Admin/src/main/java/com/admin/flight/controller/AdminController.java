package com.admin.flight.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.admin.flight.model.Airlines;
import com.admin.flight.model.Flight;
import com.admin.flight.service.AdminService;



@RequestMapping("/admin")
@RestController
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	
	@PostMapping(value = "/api/v1.0/flight/airline/register")
	public String addAirline(@RequestBody Airlines airline,HttpServletResponse httpResponse) {
		String msg=adminService.addAirlineService(airline);
		//httpResponse.setStatus(Integer.parseInt(bookings.getCode()));
		return msg;
	}
	
	
	@PutMapping(value = "/api/v1.0/flight/airline/block")
	public String blockAirline(@RequestParam(required = false) final int airlineId,
			HttpServletResponse httpResponse) {
		String msg=adminService.blockAirlineService(airlineId);
		//httpResponse.setStatus(Integer.parseInt(bookings.getCode()));
		return msg;
	}
	
	@PutMapping(value = "/api/v1.0/flight/airline/addInventory/flightSchedule")
	public String addInventoryFlightSchedule(@RequestBody Flight flight,
			HttpServletResponse httpResponse) {
		String msg=adminService.addInventoryFlightSchedule(flight);
		//httpResponse.setStatus(Integer.parseInt(bookings.getCode()));
		return msg;
	}

}
