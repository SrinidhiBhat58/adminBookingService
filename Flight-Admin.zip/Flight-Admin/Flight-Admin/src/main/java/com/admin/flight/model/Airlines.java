package com.admin.flight.model;

import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name ="Airlines")
public class Airlines {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "Id")
	@JsonProperty("id")
    public int id;
	
	@Column(name = "Airline_Id")
	@JsonProperty("airline_Id")
    public int airlineId;
	
	@Column(name = "Airline_Name")
	@JsonProperty("airlineName")
    public String airlineName;
	
	@Column(name = "Status")
	@JsonProperty("Status")
    public String status;
	
	@Column(name = "Airline_Country")
	@JsonProperty("airlineCountry")
    public String airlineCountry;
	
	@Transient
	@JsonProperty("flight")
	public ArrayList<Flight> flight;
	
	

	public ArrayList<Flight> getFlight() {
		return flight;
	}

	public void setFlight(ArrayList<Flight> flight) {
		this.flight = flight;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAirlineId() {
		return airlineId;
	}

	public void setAirlineId(int airlineId) {
		this.airlineId = airlineId;
	}

	public String getAirlineName() {
		return airlineName;
	}

	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAirlineCountry() {
		return airlineCountry;
	}

	public void setAirlineCountry(String airlineCountry) {
		this.airlineCountry = airlineCountry;
	}
	
	
	
	
}