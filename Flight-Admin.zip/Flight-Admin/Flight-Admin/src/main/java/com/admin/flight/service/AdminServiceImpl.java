package com.admin.flight.service;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin.flight.model.Airlines;
import com.admin.flight.model.Flight;
import com.admin.flight.repository.AirlineRepository;
import com.admin.flight.repository.FlightCrudRepository;
import com.admin.flight.repository.FlightRepository;

@Service
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	FlightRepository flightRepository;
	
	@Autowired
	FlightCrudRepository flightCrudRepository;
	
	@Autowired
	AirlineRepository airlineRepository;
	
		private static final Logger log = LoggerFactory.getLogger(AdminServiceImpl.class);

	@Override
	public String addAirlineService(Airlines airline) {
			
			log.info("*** Json Request Received ***" + airline);
			ArrayList<Flight> flightList = new ArrayList<>();
			flightList= airline.getFlight();
			flightList.stream().forEach(flight -> {
				 flight.setAirlineId(airline.getAirlineId());
				  flightRepository.save(flight);  });
				
			airlineRepository.save(airline);
			String successmsg="AIRLINE SUCCESSFULLY ADDED";
			return successmsg;
		}

	@Override
	public String blockAirlineService(int airlineId) {
		Airlines airlines=airlineRepository.findByAirlineId(airlineId);
		airlines.setStatus("BLOCKED");
		airlineRepository.save(airlines);
		ArrayList<Flight> flightList =flightRepository.findByAirlineId(airlineId);
		flightList.stream().forEach(flight -> {
		flight.setStatus("BLOCKED");
		flightRepository.save(flight);  });
		return("AIRLINE NO- " +airlineId+ " CANCELLED SUCCESSFULLY");	
		}
	
	@Override
	public String addInventoryFlightSchedule(Flight flight) {
		flightCrudRepository.save(flight);  
		return("Changes for flight  successfully updated");	
		}
		
}

